import java.io.Serializable;

// Abstract class representing a product and implementing Serializable
public abstract class Product implements Serializable {
    private String productType;  // Type of the product (e.g., Electronics, Clothing)
    private String productId;  // Unique identifier for the product
    private String productName;  // Name of the product
    private int availableItems;  // Number of available items in stock
    private double price;
    private int quantity; // Price of the product

    // Constructors
    public Product(String productType, String productId, String productName, int availableItems, double price) {
        // Initialize instance variables with provided values
        this.productType = productType;
        this.productId = productId;
        this.productName = productName;
        this.availableItems = availableItems;
        this.price = price;
    }

    // Getter method for product type
    public String getproductType() {
        return productType;
    }

    // Getter method for product ID
    public String getProductId() {
        return productId;
    }

    // Getter method for product name
    public String getProductName() {
        return productName;
    }

    // Getter method for available items
    public int getAvailableItems() {
        return availableItems;
    }

    // Setter method for available items
    public void setAvailableItems(int availableItems) {
        this.availableItems = availableItems;
    }

    // Getter method for product price
    public double getPrice() {
        return price;
    }

    // Abstract method to display product information (to be implemented by subclasses)
    public abstract void displayProductInfo();

    // Abstract method to get product details as a String (to be implemented by subclasses)
    public abstract String getProductDetails();

    public int getQuantity() {
        return quantity;
    }

    // New method to set the quantity
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
