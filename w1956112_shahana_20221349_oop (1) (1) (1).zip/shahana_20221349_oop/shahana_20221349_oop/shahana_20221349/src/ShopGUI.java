import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;


public class ShopGUI extends JFrame {


    private WestminsterShoppingManager shoppingManager;

    private List<User> registeredUsers;
    public static Collection<Product> cart;
    private boolean cartOpen = false;

    CartGUI shoppingCart;


    public ShopGUI(WestminsterShoppingManager shoppingManager, List<User> registeredUsers) {
        // Initialize the main frame
        setTitle("Product Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Store the WestminsterShoppingManager instance
        this.shoppingManager = shoppingManager;
        this.registeredUsers = registeredUsers;
        this.cart = (cart != null) ? cart : new HashSet<>();

        // Create a login dialog
        LoginDialog loginDialog = new LoginDialog(this, shoppingManager, registeredUsers);

        // Show the login dialog and wait for user input
        loginDialog.setVisible(true);

        // Check if the user has successfully logged in
        if (loginDialog.isLoggedIn()) {
            // User has logged in successfully, proceed with the main application window
            Container background = getContentPane();
            background.setLayout(new GridLayout(2, 1));

            // Top panel contains product display and selection components
            JPanel topPanel = new JPanel();
            topPanel.setLayout(new GridLayout(2, 1));
            background.add(topPanel, BorderLayout.NORTH);

            // Top information panel with instructions, category selection, and shopping cart button
            JPanel topInfoPanel = new JPanel();
            topInfoPanel.setLayout(new GridLayout(1, 3));
            topPanel.add(topInfoPanel, BorderLayout.NORTH);

            // Panel for instructions
            JPanel instructPanel = new JPanel(new FlowLayout());
            topInfoPanel.add(instructPanel, BorderLayout.WEST);

            // Panel for category selection
            JPanel selectionPanel = new JPanel(new FlowLayout());
            topInfoPanel.add(selectionPanel, BorderLayout.EAST);

            // Panel for shopping cart button
            JPanel topButtonPanel = new JPanel(new FlowLayout());
            topInfoPanel.add(topButtonPanel, BorderLayout.CENTER);

            // Label for instructions
            JLabel instructions = new JLabel("Select Product Category");
            instructPanel.add(instructions, BorderLayout.WEST);

            // Dropdown for product category selection
            String[] selection = {"All", "Electronics", "Clothing"};
            JComboBox<String> dropDown = new JComboBox<>(selection);
            selectionPanel.add(dropDown, BorderLayout.EAST);

            // Button to open/close shopping cart
            JButton shopCart = new JButton("Shopping Cart");
            topButtonPanel.add(shopCart, BorderLayout.CENTER);

            // Table to display products
            String[] columns = {"Product ID", "Name", "Category", "Price(£)", "Info"};
            DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
            JTable table = new JTable(tableModel);

            // Populate the table with product data
            for (Product product : WestminsterShoppingManager.productList) {
                Object[] row = new Object[5];
                row[0] = product.getProductId();
                row[1] = product.getProductName();
                row[2] = product.getproductType();
                row[3] = product.getPrice();
                row[4] = product.getProductDetails();
                tableModel.addRow(row);
            }

            // Event listener for category selection changes
            dropDown.addItemListener(new ItemListener() {
                @Override
                public void itemStateChanged(ItemEvent e) {
                    // Handle category selection change
                    if (e.getStateChange() == ItemEvent.SELECTED) {
                        String selectedCategory = (String) e.getItem();

                        // Clear the table
                        tableModel.setRowCount(0);

                        // Filter and add products based on the selected category
                        for (Product pro : WestminsterShoppingManager.productList) {
                            if ("All".equals(selectedCategory) || (pro.getproductType() != null && pro.getproductType().equals(selectedCategory))) {
                                Object[] row = new Object[5];
                                row[0] = pro.getProductId();
                                row[1] = pro.getProductName();
                                row[2] = pro.getproductType();
                                row[3] = pro.getPrice();
                                row[4] = pro.getProductDetails();
                                tableModel.addRow(row);
                            }
                        }
                    }
                }
            });

            // Scroll pane for the product table
            JScrollPane scrollPane = new JScrollPane(table);
            topPanel.add(scrollPane, new FlowLayout());

            // Bottom panel contains selected product details and "Add to Shopping Cart" button
            JPanel bottomPanel = new JPanel();
            bottomPanel.setLayout(new GridLayout(2, 1));
            background.add(bottomPanel, BorderLayout.SOUTH);

            // Label to display selected product details
            JLabel bottomLabel = new JLabel();
            bottomPanel.add(bottomLabel, new FlowLayout());

            //   Event listener for table row selection
            table.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    //Handle mouse click on a table row
                    int row = table.rowAtPoint(e.getPoint());
                    if (row >= 0) {
                        for (Product p : WestminsterShoppingManager.productList) {
                            if (p.getProductId() == table.getValueAt(row, 0)) {
                                // Generate and display product details in the label
                                StringBuilder selectedRowInfo = new StringBuilder("<html>" +
                                        "   Selected Products - Details" + "<br/>" + "------------------------"+"<br/>" +
                                        "   Product ID : " + p.getProductId() + "<br/>" +
                                        "   Category : " + (p.getproductType() != null ? p.getproductType() : " ") + "<br/>");

                                if ("Clothing".equals(p.getproductType())) {
                                    selectedRowInfo.append("<html>" +
                                            "   Name : " + p.getProductName() + "<br/>" +
                                            p.getProductDetails());
                                } else if ("Electronics".equals(p.getproductType())) {
                                    selectedRowInfo.append("<html>" +
                                            "   Name : " + p.getProductName() + "<br/>" + p.getProductDetails());

                                }

                                selectedRowInfo.append("    Items Available: " + p.getAvailableItems() + "<br/>" + "</html>");
                                bottomLabel.setText(selectedRowInfo.toString());
                            }
                        }
                    }
                }
            });




            // Button to add the selected product to the shopping cart
            JButton addToCart = new JButton("Add to Shopping Cart");
            addToCart.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Handle "Add to Shopping Cart" button click
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        for (Product p : WestminsterShoppingManager.productList) {
                            if (p.getProductId() == table.getValueAt(selectedRow, 0)) {
                                // Update product stock and add to cart
                                int currentStock = p.getAvailableItems();
                                if (currentStock != 0) {
                                    p.setAvailableItems(currentStock - 1);
                                    cart.add(p);
                                }

                                // Change table cell color if stock is low
                                if (currentStock <4) {
                                    table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
                                        @Override
                                        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                                            final Component com = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                                            com.setForeground(row == selectedRow ? Color.RED : Color.BLACK);
                                            return com;
                                        }
                                    });
                                }
                            }
                        }
                    }

                    // Update shopping cart window if open
                    if (cartOpen) {
                        shoppingCart.dispose();
                        shoppingCart = new CartGUI();
                        shoppingCart.setSize(600, 500);
                        shoppingCart.setVisible(true);
                        shoppingCart.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                        cartOpen = true;
                    }
                }
            });

            // Bottom button panel
            JPanel bottomBtnPanel = new JPanel();
            bottomPanel.add(bottomBtnPanel, BorderLayout.SOUTH);
            bottomBtnPanel.add(addToCart, BorderLayout.SOUTH);

            // Event listener for shopping cart button
            shopCart.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Handle shopping cart button click
                    if (!CartGUI.cartOpen) {
                        CartGUI.cartOpen = true;
                        CartGUI shoppingCart = new CartGUI();
                        shoppingCart.setSize(600, 500);
                        shoppingCart.setVisible(true);
                        shoppingCart.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    }
                }
            });


        }
    }
}
