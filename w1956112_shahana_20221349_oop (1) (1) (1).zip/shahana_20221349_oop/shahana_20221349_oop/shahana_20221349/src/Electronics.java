import java.io.Serializable;

// Electronics class extending Product and implementing Serializable
public class Electronics extends Product implements Serializable {
    private String brand;  // Brand of the electronics
    private double warrantyPeriod;  // Warranty period for the electronics (assuming it is in months)

    // Constructors
    public Electronics(String productType, String productID, String productName, int availableItems, double price, String brand, double warrantyPeriod) {
        // Call the constructor of the superclass (Product)
        super(productType, productID, productName, availableItems, price);
        this.brand = brand;  // Initialize brand
        this.warrantyPeriod = warrantyPeriod;  // Initialize warranty period
    }

    // Getter method for brand
    public String getBrand() {
        return brand;
    }

    // Getter method for warranty period
    public double getWarrantyPeriod() {
        return warrantyPeriod;
    }

    // Method to display product information
    public void displayProductInfo() {
        System.out.println("Product TYPE: " + getproductType());
        System.out.println("Product ID: " + getProductId());
        System.out.println("Product Name: " + getProductName());
        System.out.println("Available Items: " + getAvailableItems());
        System.out.println("Price: " + getPrice());
        System.out.println("Brand: " + brand);
        System.out.println("Warranty Period: " + warrantyPeriod + " months");
    }

    // Method to get product details as a String
    public String getProductDetails() {
        // Implement the logic to return Electronics details as a String
        return "Brand: " + brand + "\n"+ "Warranty Period :"  + warrantyPeriod + " months";
    }

    // Override toString method to provide a string representation of the object
    @Override
    public String toString() {
        return "Product TYPE: " + getproductType() + "\n" +
                "productId='" + getProductId() + '\'' + "\n" +
                "productName='" + getProductName() + '\'' + "\n" +
                "availableItems=" + getAvailableItems() + "\n" +
                "price=" + getPrice() + "\n" +
                "brand='" + brand + '\'' + "\n" +
                "warrantyPeriod=" + warrantyPeriod + "\n";
    }


}
