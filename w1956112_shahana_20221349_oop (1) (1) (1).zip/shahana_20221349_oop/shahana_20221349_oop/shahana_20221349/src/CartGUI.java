import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.*;

public class CartGUI extends JFrame {

    // Flag to check if the shopping cart window is open
    public static boolean cartOpen;

    // Constructor for the ShoppingCartGUI class
    public CartGUI() {
        super("Shopping Cart");  // Set the title of the JFrame
        Container background = getContentPane();  // Get the content pane for the JFrame
        background.setLayout(new GridLayout(2, 1, 10, 10));  // Set the layout for the content pane

        // Create a set to store unique products in the shopping cart
        Set<Product> uniqueSet = new HashSet<>(ShopGUI.cart);

        // Create an ArrayList from the unique set
        ArrayList<Product> shopCart = new ArrayList<>(uniqueSet);

        // Define columns for the JTable in the shopping cart
        String[] columns = {"Product", "Quantity", "Price(£)"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);

        // Populate the tableModel with data from the shopping cart
        for (Product p : shopCart) {
            // Count the occurrences of each product in the shopping cart
            int count = Collections.frequency(ShopGUI.cart, p);

            // Create a row for the JTable
            Object[] row = new Object[3];
            row[0] = "<html>" + p.getProductId() + "<br/>" + p.getProductName() + "<br/>" + p.getProductDetails() + "</html>";
            row[1] = count;
            row[2] = Math.round(p.getPrice() * count) * 100 / 100 + " £";
            tableModel.addRow(row);
        }

        // Create JTable with the populated tableModel
        JTable table = new JTable(tableModel);
        table.setRowHeight(60);  // Set row height for better visibility
        JScrollPane scrollPane = new JScrollPane(table);

        // Add the table to the top part of the JFrame
        background.add(scrollPane, new FlowLayout());

        // Calculate discounts and total cost
        double total = 0;
        int clothing = 0;
        int electronics = 0;
        double firstDis = 0;
        double secondDis = 0;

        // Iterate through products in the shopping cart to calculate total and count of clothing and electronics
        for (Product p : ShopGUI.cart) {
            total += p.getPrice();
            if (p.getproductType() != null) {
                if (p.getproductType().equals("Clothing")) {
                    clothing++;
                } else if (p.getproductType().equals("Electronics")) {
                    electronics++;
                }
            }
        }

        // Apply first purchase discount (10%)
        if (true) {  // The condition seems to be a placeholder; you may want to replace it with a meaningful one
            firstDis = (Math.round(total * 0.1) * 100) / 100;
        }

        // Apply discount for buying three items in the same category
        if (clothing >= 3 || electronics >= 3) {
            secondDis = (Math.round(total * 0.2) * 100) / 100;
        }

        // Create strings for information display
        StringBuilder infoWords = new StringBuilder("<html>" + "   Total <br/><br/>" +
                "First Purchase Discount (10%)  <br/><br/>" +
                "Three Items in the same Category Discount  <br/><br/>" +
                "Final Total </html>");

        StringBuilder infoNums = new StringBuilder("<html>" + total + "  £ <br/><br/>" +
                "-" + firstDis + "  £ <br/><br/>" +
                "-" + secondDis + "  £ <br/><br/>" +
                +(Math.round(total - firstDis - secondDis) * 100) / 100 + "  £ </html>");

        // Create a panel to display information side by side
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 2));

        // Create labels for displaying information
        JLabel words = new JLabel(String.valueOf(infoWords));
        panel.add(words, BorderLayout.EAST);
        JLabel nums = new JLabel(String.valueOf(infoNums));
        panel.add(nums, BorderLayout.EAST);

        // Add the information panel to the bottom part of the JFrame
        background.add(panel, new FlowLayout());
    }
}
