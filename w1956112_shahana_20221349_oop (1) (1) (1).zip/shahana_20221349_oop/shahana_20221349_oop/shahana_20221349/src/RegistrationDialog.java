// Import necessary Swing classes and AWT event classes
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// RegistrationDialog class extending JDialog
public class RegistrationDialog extends JDialog {
    // Fields for user registration information
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField phoneNumberField; // New field for phone number
    private JTextField emailField;

    // Flags to track registration status
    private boolean isRegistered;
    private User registeredUser;

    // Constructor for the registration dialog
    public RegistrationDialog(JFrame parent) {
        // Call the constructor of the superclass (JDialog) with title, modality, and size
        super(parent, "Customer Registration", true);
        setSize(400, 300);
        setLocationRelativeTo(parent);

        // Initialize flags
        isRegistered = false;

        // Initialize text fields for user input
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        phoneNumberField = new JTextField(20); // New field for phone number
        emailField = new JTextField(20);

        // Set layout as a 5x2 grid
        setLayout(new GridLayout(5, 2));

        // Add labels and corresponding text fields to the dialog
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(new JLabel("Phone Number:")); // New label for phone number
        add(phoneNumberField); // New field for phone number
        add(new JLabel("Email:")); // New label for email
        add(emailField);

        // Add Register button with ActionListener for user registration
        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String enteredUsername = usernameField.getText();
                char[] enteredPassword = passwordField.getPassword();

                // Check if both username and password are provided
                if (enteredUsername.length() > 0 && enteredPassword.length > 0) {
                    // Create a new User object with entered credentials
                    registeredUser = new User(enteredUsername, new String(enteredPassword));
                    isRegistered = true;
                    // Close the registration dialog
                    dispose();
                } else {
                    // Show an error message if either username or password is empty
                    JOptionPane.showMessageDialog(RegistrationDialog.this, "Invalid username or password");
                }

                // Clear the password field after registration attempt
                passwordField.setText("");
            }
        });
        add(registerButton);

        // Add Cancel button with ActionListener for canceling registration
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Set registration status to false and close the dialog
                isRegistered = false;
                dispose();
            }
        });
        add(cancelButton);
    }

    // Getter method to check if the registration is successful
    public boolean isRegistered() {
        return isRegistered;
    }

    // Getter method to retrieve the registered user information
    public User getRegisteredUser() {
        return registeredUser;
    }
}
