// Import necessary libraries
import javax.swing.*;
import java.util.*;
import java.io.*;
import java.util.List;

// Class definition for WestminsterShoppingManager, extending JFrame and implementing ShoppingManager interface
public class WestminsterShoppingManager extends JFrame implements ShoppingManager {

    // Static list to store products
    static  ArrayList<Product> productList;

    // Instance variables for user, registered users, and shopping cart
    private User user;
    private List<User> registeredUsers = new ArrayList<>();
    private ShoppingCart shoppingCart;

    // Constructor for WestminsterShoppingManager
    public WestminsterShoppingManager() {

        // Initialize product list, user, and shopping cart
        this.productList = new ArrayList<>();
        this.user = null;
        this.shoppingCart = new ShoppingCart();
        loadProductsFromFile();

        // Create a scanner for user input
        Scanner scanner = new Scanner(System.in);
        String userType;

        // User type selection loop
        do {
            System.out.println("****Welcome to SAI shopping market*** ");
            System.out.println("--------------------------------------");
            System.out.print("Are you a manager or a customer? ");
            userType = scanner.nextLine().toLowerCase();

            // Branch based on user type
            if ("manager".equals(userType)) {
                runConsoleMenu(); // If manager, run console menu
            } else if ("customer".equals(userType)) {
                registrationForm(); // If customer, go through registration and then run console menu
                runConsoleMenu();
            } else {
                System.out.println("Invalid user type. Please enter 'manager' or 'customer'.");
                System.out.println();
            }
        } while (!("manager".equals(userType) || "customer".equals(userType)));
    }
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }


    public static List<Product> getProductList() {
        return new ArrayList<>(productList);
    }





    // Implementation of the addNewProduct method from the ShoppingManager interface
    @Override
    public void addNewProduct() {
        Scanner scanner = new Scanner(System.in);
        String productType;

        // Prompt user to enter the product type
        System.out.print("Enter the product type (Electronics/Clothing): ");
        productType = scanner.nextLine();

        // Branch based on product type
        if (productType.equalsIgnoreCase("Electronics")) {
            System.out.println("Please Enter the details of "+productType);
            addElectronicsProduct(productType); // If Electronics, call method to add electronics product
        } else if (productType.equalsIgnoreCase("Clothing")) {
            System.out.println("Please Enter the details of "+productType);
            addClothingProduct(productType); // If Clothing, call method to add clothing product
        } else {
            System.out.println("Invalid product type.please type either Clothing or Electronics.");
            System.out.println();
            addNewProduct();
        }
    }

    // Method to display registration form
    private void registrationForm() {
        RegistrationDialog registrationDialog = new RegistrationDialog(this);
        registrationDialog.setVisible(true);

        // If user is registered, add to the list of registered users
        if (registrationDialog.isRegistered()) {
            User newUser = registrationDialog.getRegisteredUser();
            registeredUsers.add(newUser);
            System.out.println("Customer registered successfully!");
            System.out.println();
        } else {
            System.out.println("Customer registration canceled.");
        }
    }

    // Method to print the product list
    // Method to print the product list
    public void printProductList() {
        System.out.println("Details of added products"); // Print header
        System.out.println(); // Print empty line for separation
        productList.sort(Comparator.comparing(Product::getProductId)); // Sort the product list by product ID

        for (Product product : productList) { // Iterate through each product in the sorted list
            String[] productDetails = product.toString().split(", "); // Split product details into an array
            for (String detail : productDetails) {
                System.out.println(detail); // Print each detail of the product
            }
            System.out.println(); // Separate each product's details with an empty line
        }
    }


    // Method to save products to a file
    public void saveProductsToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("product.txt"))) {
            oos.writeObject(productList); // Write the product list to the file
            System.out.println("Products saved to file successfully."); // Print success message
        } catch (IOException e) {
            System.out.println("Error saving products to file: " + e.getMessage()); // Print error message if saving fails
        }
    }

    // Method to load products from a file
    public void loadProductsFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("product.txt"))) {
            productList = (ArrayList<Product>) ois.readObject(); // Read the product list from the file
            System.out.println("Products loaded from file successfully."); // Print success message
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading products from file: " + e.getMessage()); // Print error message if loading fails
        }
    }


    // Method to delete a product
    // Method to delete a product
    public void deleteProduct() {
        Scanner scanner = new Scanner(System.in); // Create a scanner for user input
        System.out.println("Enter the product id you are willing to delete?"); // Prompt user to enter product ID

        String productId = scanner.nextLine(); // Read user input for product ID

        // Use iterator to safely remove the product from the list
        Iterator<Product> iterator = productList.iterator(); // Create an iterator for the product list
        boolean found = false; // Flag to track whether the product is found

        // Iterate through the product list
        while (iterator.hasNext()) { // Loop while there are more elements in the product list
            Product product = iterator.next(); // Get the next product from the list

            // If the product ID matches, remove the product
            if (product.getProductId().equals(productId)) {
                iterator.remove(); // Remove the product from the list
                System.out.println(product.getproductType() + " product deleted successfully:"); // Print success message
                System.out.println("Deleted product details");
                System.out.println();
                System.out.println(product); // Print details of the deleted product

                // Update availableItems for the deleted product

                System.out.println("Total number of products left in the system: " + productList.size()); // Print the total number of remaining products
                found = true; // Set the flag to indicate that the product was found
                break; // Exit the loop after deleting the product
            }
        }

        // If the product is not found
        if (!found) {
            System.out.println("Product not found. Please enter the valid id"); // Print error message
            deleteProduct(); // Recursively call deleteProduct to allow the user to try again
        }
    }

    // Method to run the console menu
    public void runConsoleMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        // Main menu loop
        do {
            System.out.println("Menu:");
            System.out.println("1. Add a new product");
            System.out.println("2. Delete a product");
            System.out.println("3. Print product list");
            System.out.println("4. Save products to file");
            System.out.println("5. Load products from file");
            System.out.println("6. Customer GUI: ");
            System.out.println("0. Exit");

            try {
                System.out.print("Enter your choice: ");
                choice = Integer.parseInt(scanner.nextLine());

                // Check if the choice is within the valid range
                if (choice < 0 || choice > 6) {
                    System.out.println("Choice outside of range. Please choose again.");
                } else {
                    // Switch based on user choice
                    switch (choice) {
                        case 1:
                            addNewProduct();
                            break;
                        case 2:
                            // Check if products are available before attempting to delete
                            if (productList.size() > 0) {
                                deleteProduct();
                            } else {
                                System.out.println("No products are available in the system\n Please add a product to the system first");
                            }
                            break;
                        case 3:
                            // Check if products are available before attempting to print
                            if (productList.size() > 0) {
                                printProductList();
                            } else {
                                System.out.println("No products are available in the system\n Please add a product to the system first");
                            }
                            break;
                        case 4:
                            saveProductsToFile();
                            break;
                        case 5:
                            loadProductsFromFile();
                            break;
                        case 6:
                            ShopGUI();
                            break;
                        case 0:
                            System.out.println("Exiting the system. Goodbye!");
                            System.exit(0);
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid selection. Numbers only please.");
                choice = -1;  // Set to an invalid value to repeat the loop
            }
        } while (choice != 0);
    }

    // Method to launch the customer GUI
    public void ShopGUI() {
        ShopGUI shoppingAppGUI = new ShopGUI(this, registeredUsers);
        shoppingAppGUI.setVisible(true);
    }

    // Method to add an electronics product
    private void addElectronicsProduct(String productType) {
        Scanner scanner = new Scanner(System.in);

        // Validate and add electronics product details
        while (productList.size() < 50) {
            // Product ID validation
            String productId;
            do {
                System.out.print("Enter product ID: ");
                productId = scanner.nextLine().trim();

                if (productId.isEmpty()) {
                    System.out.println(" Product ID cannot be empty.");
                } else if (isProductIdDuplicate(productId)) {
                    System.out.println(" Product ID already exists. Please enter a unique Product ID.");
                } else if (!productId.matches("^[a-zA-Z][a-zA-Z0-9]*$")) {
                    System.out.println(" Product ID should start with a letter and contain alphanumeric characters.");
                }
            } while (productId.isEmpty() || isProductIdDuplicate(productId) || !productId.matches("^[a-zA-Z][a-zA-Z0-9]*$"));

            // Product Name validation
            String productName;
            do {
                System.out.print("Enter product name: ");
                productName = scanner.nextLine().trim();

                if (productName.isEmpty()) {
                    System.out.println("Product name cannot be empty.");
                } else if (productName.matches(".*\\d.*")) {
                    System.out.println("Product name should not contain digits.");
                }
            } while (productName.isEmpty() || productName.matches(".*\\d.*"));

            // Available Items validation
            int availableItems = 0;
            do {
                System.out.print("Enter available items: ");
                String availableItemsInput = scanner.nextLine().trim();

                try {
                    availableItems = Integer.parseInt(availableItemsInput);

                    // Validate if availableItems is positive
                    if (availableItems <= 0) {
                        System.out.println("Available items should be a positive integer.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println(" Available items should be a positive integer.");
                }
            } while (availableItems <= 0);

            // Price validation
            double price = 0;
            do {
                System.out.print("Enter price: ");
                String priceInput = scanner.nextLine().trim();

                try {
                    price = Double.parseDouble(priceInput);

                    // Validate if price is positive
                    if (price <= 0) {
                        System.out.println("Price should be a positive integer.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println(" Price should be a positive integer.");
                }
            } while (price <= 0.0);

            // Brand validation
            String brand;
            do {
                System.out.print("Enter brand: ");
                brand = scanner.nextLine().trim();

                if (brand.isEmpty()) {
                    System.out.println("Brand cannot be empty.");
                } else if (brand.matches(".*\\d.*")) {
                    System.out.println(" Brand should not contain digits.");
                }
            } while (brand.isEmpty() || brand.matches(".*\\d.*"));

            // Warranty Period validation
            int warrantyPeriod = 0;
            do {
                System.out.print("Enter warranty period (in months): ");
                String warrantyPeriodInput = scanner.nextLine().trim();

                try {
                    warrantyPeriod = Integer.parseInt(warrantyPeriodInput);
                } catch (NumberFormatException e) {
                    System.out.println("Warranty period should be an integer.");
                }
            } while (warrantyPeriod <= 0);

            // After validating all fields, create an Electronics object and add it to the product list
            Electronics electronics = new Electronics(productType, productId, productName, availableItems, price, brand, warrantyPeriod);
            productList.add(electronics);

            // Prompt user to add another product
            while (true) {
                System.out.print("Do you want to add another product? (yes/no): ");

                try {
                    String choice = scanner.nextLine().toLowerCase();

                    while (!choice.equals("yes") && !choice.equals("no")) {
                        System.out.println("Please enter 'yes' or 'no' only.");
                        System.out.print("Do you want to add another product? (yes/no): ");
                        choice = scanner.nextLine().toLowerCase();
                    }

                    if (choice.equals("no")) {
                        System.out.println("Thank you for adding.");
                        runConsoleMenu();
                        break;
                    } else {
                        System.out.println();
                        addNewProduct();
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Error: Please enter a valid string value.");
                    // Clear the buffer
                    scanner.nextLine();
                } catch (IllegalArgumentException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }

        }

        // Display a message if the maximum product limit is reached
        if (productList.size() >= 50) {
            System.out.println("Cannot add more than 50 products in total.");
        }
    }

    // Method to add a clothing product
    // Method to add a clothing product
    private void addClothingProduct(String productType) {
        Scanner scanner = new Scanner(System.in);

        // Validate and add clothing product details
        while (productList.size() < 50) {
            // Product ID validation
            String productId;
            do {
                System.out.print("Enter product ID: ");
                productId = scanner.nextLine().trim();

                if (productId.isEmpty()) {
                    System.out.println("Product ID cannot be empty.");
                } else if (isProductIdDuplicate(productId)) {
                    System.out.println(" Product ID already exists. Please enter a unique Product ID.");
                } else if (!productId.matches("^[a-zA-Z][a-zA-Z0-9]*$")) {
                    System.out.println(" Product ID should start with a letter and contain alphanumeric characters.");
                }
            } while (productId.isEmpty() || isProductIdDuplicate(productId) || !productId.matches("^[a-zA-Z][a-zA-Z0-9]*$"));

            // Product Name validation
            String productName;
            do {
                System.out.print("Enter product name: ");
                productName = scanner.nextLine().trim();

                if (productName.isEmpty()) {
                    System.out.println("Product name cannot be empty.");
                } else if (productName.matches(".*\\d.*")) {
                    System.out.println(" Product name should not contain digits.");
                }
            } while (productName.isEmpty() || productName.matches(".*\\d.*"));

            // Available Items validation
            int availableItems = 0;
            do {
                System.out.print("Enter available items: ");
                String availableItemsInput = scanner.nextLine().trim();

                try {
                    availableItems = Integer.parseInt(availableItemsInput);

                    // Validate if availableItems is positive
                    if (availableItems <= 0) {
                        System.out.println(" Available items should be a positive integer.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println(" Available items should be a  integer.");
                }
            } while (availableItems <= 0);

            // Price validation
            double price = 0;
            do {
                System.out.print("Enter price: ");
                String priceInput = scanner.nextLine().trim();

                try {
                    price = Double.parseDouble(priceInput);

                    // Validate if price is positive
                    if (price <= 0) {
                        System.out.println("Price should be a positive integer.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Price should be a integer.");
                }
            } while (price <= 0.0);

            // Size validation
            String size;
            do {
                System.out.print("Enter size (S, M, L, XL, XXL): ");
                size = scanner.nextLine().toUpperCase();

                // Validate size
                if (!size.matches("S|M|L|XL|XXL")) {
                    System.out.println("Size must be S, M, L, XL, or XXL.");
                }
            } while (!size.matches("S|M|L|XL|XXL"));

            // Color validation
            String color;
            do {
                System.out.print("Enter color (red, black, white, orange, blue): ");
                color = scanner.nextLine().toLowerCase();

                // Validate color
                if (!color.matches("red|black|white|orange|blue")) {
                    System.out.println(" Color must be red, black, white, orange, or blue.");
                }
            } while (!color.matches("red|black|white|orange|blue"));

            // After validating all fields, create a Clothing object and add it to the product list
            Clothing clothing = new Clothing(productType, productId, productName, availableItems, price, size, color);
            productList.add(clothing);

            // Prompt user to add another product
            while (true) {
                System.out.print("Do you want to add another product? (yes/no): ");

                try {
                    String choice = scanner.nextLine().toLowerCase();

                    while (!choice.equals("yes") && !choice.equals("no")) {
                        System.out.println(" Please enter 'yes' or 'no' only.");
                        System.out.print("Do you want to add another product? (yes/no): ");
                        choice = scanner.nextLine().toLowerCase();
                    }

                    if (choice.equals("no")) {
                        System.out.println("Thank you for adding.");
                        runConsoleMenu();
                        break;
                    } else {
                        System.out.println();
                        addNewProduct();
                    }
                } catch (InputMismatchException e) {
                    System.out.println(" Please enter a valid string value.");
                    // Clear the buffer
                    scanner.nextLine();
                } catch (IllegalArgumentException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }

        }

        // Display a message if the maximum product limit is reached
        if (productList.size() >= 50) {
            System.out.println("Cannot add more than 50 products in total.");
        }
    }

    // Method to check if a product ID already exists (duplicate)
    private boolean isProductIdDuplicate(String productId) {
        for (Product product : productList) {
            if (product.getProductId().equals(productId)) {
                return true;  // Product ID already exists
            }
        }
        return false;  // Product ID is not duplicate
    }
}
