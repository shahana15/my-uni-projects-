import java.util.ArrayList;

// Interface defining methods for shopping system management
public interface ShoppingManager {

    // Method to add a new product to the shopping system
    void addNewProduct();

    // Method to delete a product from the shopping system
    void deleteProduct();

    // Method to print the list of products in the shopping system
    void printProductList();

    // Method to save the products to a file for persistence
    void saveProductsToFile();

    // Method to load products from a file for system initialization
    void loadProductsFromFile();
}
