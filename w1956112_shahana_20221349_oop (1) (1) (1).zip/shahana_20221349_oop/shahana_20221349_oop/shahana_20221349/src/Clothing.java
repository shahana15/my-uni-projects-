import java.io.Serializable;

// Clothing class extending Product and implementing Serializable
public class Clothing extends Product implements Serializable {
    private String size;  // Size of the clothing
    private String color;  // Color of the clothing

    // Constructors
    public Clothing(String productType, String productID, String productName, int availableItems, double price, String size, String color) {
        // Call the constructor of the superclass (Product)
        super(productType, productID, productName, availableItems, price);
        this.size = size;  // Initialize size
        this.color = color;  // Initialize color
    }

    // Getter method for size
    public String getSize() {
        return size;
    }

    // Getter method for color
    public String getColor() {
        return color;
    }

    // Method to display product information
    public void displayProductInfo() {
        System.out.println("Product TYPE: " + getproductType());
        System.out.println("Product ID: " + getProductId());
        System.out.println("Product Name: " + getProductName());
        System.out.println("Available Items: " + getAvailableItems());
        System.out.println("Price: " + getPrice());
        System.out.println("Size: " + size);
        System.out.println("Color: " + color);
    }

    // Method to get product details as a String
    public String getProductDetails() {
        // Implement the logic to return Clothing details as a String
        return "Size: " + size + "\n" + "Color :" + color;
    }

    // Override toString method to provide a string representation of the object
    @Override
    public String toString() {
        return "Product TYPE: " + getproductType() + "\n" +
                "Product ID: '" + getProductId() + '\'' + "\n" +
                "Product Name: '" + getProductName() + '\'' + "\n" +
                "Available Items: " + getAvailableItems() + "\n" +
                "Price: " + getPrice() + "\n" +
                "Size: '" + size + '\'' + "\n" +
                "Color: " + color + "\n" ;
    }


}
