import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class LoginDialog extends JDialog {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private boolean isLoggedIn;
    private WestminsterShoppingManager shoppingManager;
    private List<User> registeredUsers;

    public LoginDialog(JFrame parent, WestminsterShoppingManager shoppingManager, List<User> registeredUsers) {
        super(parent, "Login", true);
        setSize(300, 150);
        setLocationRelativeTo(parent);

        // Store the WestminsterShoppingManager instance and registered users
        this.shoppingManager = shoppingManager;
        this.registeredUsers = registeredUsers;

        // Initialize components
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        isLoggedIn = false;

        // Create layout
        setLayout(new GridLayout(3, 2));
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Validate login using the WestminsterShoppingManager instance
                String enteredUsername = usernameField.getText();
                char[] enteredPassword = passwordField.getPassword();

                if (validateLogin(enteredUsername, enteredPassword)) {
                    isLoggedIn = true;
                    dispose(); // Close the login dialog
                } else {
                    JOptionPane.showMessageDialog(LoginDialog.this, "Invalid username or password");
                }

                // Clear password field
                passwordField.setText("");
            }
        });
        add(loginButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isLoggedIn = false;
                dispose(); // Close the login dialog if canceled
            }
        });
        add(cancelButton);
    }

    public boolean isLoggedIn() {
        return isLoggedIn;
    }



    // Validate the login credentials using WestminsterShoppingManager
    private boolean validateLogin(String enteredUsername, char[] enteredPassword) {
        for (User registeredUser : registeredUsers) {
            String storedUsername = registeredUser.getUsername();
            String storedPassword = registeredUser.getPassword();

            if (storedUsername.equals(enteredUsername) && storedPassword.equals(new String(enteredPassword))) {
                shoppingManager.setUser(registeredUser);
                return true;  // User is registered and credentials match
            }
        }
        return false;  // User is not registered or credentials do not match
    }
}
