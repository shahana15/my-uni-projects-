import java.util.ArrayList;

public class ShoppingCart {
    // ArrayList to store the products in the shopping cart
    public static ArrayList<Product> cart;

    // Constructor to initialize the shopping cart
    public ShoppingCart() {
        cart = new ArrayList<>();
    }

    // Method to add a product to the shopping cart
    public void addProduct(Product product) {
        this.cart.add(product);
    }

    // Method to remove a product from the shopping cart based on its name
    public void removeProduct(String productName) {
        // Use lambda expression to remove products with a matching name
        cart.removeIf(pro -> pro.getProductName().equals(productName));
    }

    public static void addToCart(Product product) {
        cart.add(product);
    }



    // Method to calculate the total cost of products in the shopping cart
    public double totalCost() {
        double total = 0;
        // Iterate through each product in the cart and accumulate their prices
        for (Product p : cart) {
            total += p.getPrice();
        }
        return total;
    }

    public ArrayList<Product> getCart() {
        return cart;
    }
}

